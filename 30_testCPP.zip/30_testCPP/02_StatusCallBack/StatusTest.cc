#include <iostream>
#include <stdio.h>
#include <string.h>
using namespace std;

#define EVENT_NUM  2
 
typedef enum
{
	CB_INIT= 0,    //    
	CB_RUN,    //  
	CB_TYPE_MAX,   //  
}cb_type;


typedef enum
{
	EV_INIT= 0,    //    
	EV_RUN,    //  
	EV_MAX,   //  
}Event_id;



typedef void(*cb_func)(void *);


class CbComm {
public:
	CbComm()
	{
		//init 2 ά  �� ��
		memset( func_list, 0x00, sizeof(cb_func)*EV_MAX*CB_TYPE_MAX );
	}

	int reg_callback(cb_type type, Event_id eventID, cb_func func)
	{
		if ((type < CB_TYPE_MAX) && (func != NULL) && (eventID < EV_MAX) )
		{
			func_list[type][eventID] = func;
		}
		else
		{
			cout << "Register callback fail Please check the param" << endl;
		}
	}

public:
	cb_func func_list[CB_TYPE_MAX][EV_MAX];
	
};


class CbTest {
public:
	CbTest();
	~CbTest();
	void Init();
	
	void static Init_eveID_1(void *args);	
	void static Init_eveID_2(void *args);
	void static run_eveID_1(void *args);
	void static run_eveID_2(void *args);
public:
	CbComm *pCbComm;

};

CbTest::CbTest()  {
	pCbComm = new CbComm();
}

CbTest::~CbTest() {
	if (pCbComm  != NULL)
	{
		delete pCbComm;
		pCbComm = NULL;
	}
}

void CbTest::Init_eveID_1(void *args)
{
	cout << "Init_eveID_1 " <<endl;
}

void CbTest::Init_eveID_2(void *args)
{
	cout << "Init_eveID_2 " <<endl;
}

void CbTest::run_eveID_1(void *args)
{
	cout << "run_eveID_1 " <<endl;
}

void CbTest::run_eveID_2(void *args)
{
	cout << "run_eveID_2 " <<endl;
}



void CbTest::Init()
{
	pCbComm->reg_callback(CB_INIT,  EV_INIT, Init_eveID_1);
	pCbComm->reg_callback(CB_INIT, EV_RUN, Init_eveID_2);
	pCbComm->reg_callback(CB_RUN,  EV_INIT, run_eveID_1);
	pCbComm->reg_callback(CB_RUN, EV_RUN, run_eveID_2);
}


int main()
{
	cb_type type       = CB_INIT;
	Event_id eventid = EV_INIT;
	
	CbTest *pCbTest = new CbTest();
	pCbTest->Init();

	if (pCbTest->pCbComm->func_list[type][eventid] != NULL)
	{
		pCbTest->pCbComm->func_list[type][eventid](NULL);
		//cout << "init()" <<endl;
	}

	eventid = EV_RUN;

	
	if (pCbTest->pCbComm->func_list[type][eventid] != NULL)
	{
		pCbTest->pCbComm->func_list[type][eventid](NULL);
	}

	type  = CB_RUN;

	
	if (pCbTest->pCbComm->func_list[type][eventid] != NULL)
	{
		pCbTest->pCbComm->func_list[type][eventid](NULL);
	}

	delete pCbTest;
	return 0;
}





