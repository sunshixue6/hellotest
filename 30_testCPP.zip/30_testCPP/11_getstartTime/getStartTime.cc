#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <iostream> // std::cout
#include <thread>   // std::thread
#include <vector>
#include <fstream>
#include <ostream>
#include <sstream>

#define MAX_LEN (50)
#define PROC_UPTIME_FILE  ("/proc/uptime")

static std::ifstream infile_;  // PRQA S 4634
static std::ofstream outfile_;  // PRQA S 4634
static std::vector<std::string> str_vector_;
static std::string log_file_name_; 
static std::string module_name_ = "testpro";

inline std::string generate_log_file_name(const std::string &module_name) {
  return std::string("./") + module_name + std::string("_launch_time_log");
}

static int record_proc_uptime() {
  std::string result;
  std::stringstream ss;
  char buf[MAX_LEN] = {0};  // PRQA S 3137
  char *ch_realTime;
  char input[16]="123.6  5555";

  infile_.open(std::string(PROC_UPTIME_FILE));

  if (!infile_.is_open()) {
    printf("Open %s fail.", PROC_UPTIME_FILE);
    return -1;
  }

  str_vector_.clear();

  infile_.getline(buf, MAX_LEN);
  ss << buf;
  printf("origin uptime:%s\n", ss.str().c_str());

  ch_realTime = strtok(input, " ");
  if (ch_realTime)
     printf("ch_realTime = %s \n", ch_realTime);

  while (ss >> result)  // PRQA S ALL
    str_vector_.push_back(result);

  printf("real uptime:%s\n", str_vector_.front().c_str());

   
  log_file_name_ = generate_log_file_name(module_name_);
  outfile_.open(log_file_name_, std::ios::trunc);  

  if (!outfile_.is_open()) {
    printf("Open %s fail.", log_file_name_.c_str());
    return -1;
  }

  const float ms = static_cast<float>(std::stof(str_vector_.front(), nullptr)) *1000U;
  outfile_ << std::string("The following time starts after the system is powered on\n");
  outfile_ << module_name_ << std::string(" start at time:") << ms << std::string(" ms\n");

  infile_.close();
  outfile_.close();

  return 0;
}


void thread_task() {
    std::cout << "hello thread" << std::endl;
}


class Test
{
    public:
        Test(int value)
        {
            this->value = value;
            std::cout << "constrort Test" << std::endl;
        }

        int funcTest() {
            auto cafunc = [this]{ return (2 * this->value); };
            return cafunc();
        }

    private:
        int value;
};

/*
 * ===  FUNCTION  =========================================================
 *         Name:  main
 *  Description:  program entry routine.
 * ========================================================================
 * // 完整语法
[ capture-list ] ( params ) mutable(optional) constexpr(optional)(c++17) exception attribute -> ret { body }

// 可选的简化语法
[ capture-list ] ( params ) -> ret { body }
[ capture-list ] ( params ) { body }
[ capture-list ] { body }
capture-list：捕捉列表，这个不用多说，前面已经讲过，记住它不能省略；
params：参数列表，可以省略（但是后面必须紧跟函数体）；
mutable：可选，将lambda表达式标记为mutable后，函数体就可以修改传值方式捕获的变量；
constexpr：可选，C++17，可以指定lambda表达式是一个常量函数；
exception：可选，指定lambda表达式可以抛出的异常；
attribute：可选，指定lambda表达式的特性；
ret：可选，返回值类型；
body：函数执行体。

 *
 *
 */
int main(int argc, const char *argv[])
{
    
    std::cout << "__cplusplus = " << __cplusplus << std::endl;
  

    record_proc_uptime();

    return 0;
}  /* ----------  end of function main  ---------- */
