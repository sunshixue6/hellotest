/**
 * @copyright Copyright 2022
 *
 * No duplications, whole or partial, manual or electronic, may be made
 * without express written permission. Any such copies, or revisions thereof,
 * must display this notice unaltered.
 *
 * @brief
 * @author 
 * @date 2022-01-23
 */

#ifndef INCLUDE_COMPLEX_H_
#define INCLUDE_COMPLEX_H_
namespace test {

class Complex {
public:
    Complex(int v_1, int v_2);
    Complex operator+(const Complex& ref1);

    void dumpValue();

private:
    int m_vaule_1;
    int m_vaule_2;
};

} //end namespace test

#endif // INCLUDE_COMPLEX_H_