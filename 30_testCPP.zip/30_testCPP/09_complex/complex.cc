#include "complex.h"
#include <iostream>

namespace test
{

//構造函數列表使用
Complex::Complex(int v_1, int v_2):m_vaule_1(v_1),m_vaule_2(v_2)
{
    
} 

Complex Complex::operator+(const Complex& ref1)
{
    Complex tmp(0, 0);
    tmp.m_vaule_1 = this->m_vaule_1 + ref1.m_vaule_1;
    tmp.m_vaule_2 = this->m_vaule_2 + ref1.m_vaule_2;

    return tmp;
}

void Complex::dumpValue()
{
    std::cout<<"m_vaule_1:" << m_vaule_1 << " ,m_vaule_2:" << m_vaule_2 << std::endl; 
}

}
