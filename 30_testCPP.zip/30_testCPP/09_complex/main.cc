#include <iostream>
#include "complex.h"
#include <memory>
int main()
{
    test::Complex cplex1(1,2);
    test::Complex cplex2(1,2);
    test::Complex cplex3(0,0);
    cplex3 = cplex1 + cplex2;

    cplex3.dumpValue();

    std::shared_ptr<test::Complex> pComplex1 = std::make_shared<test::Complex>(1, 2);
    pComplex1->dumpValue();
    return 0;
}
