#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <iostream> // std::cout
#include <thread>   // std::thread
#include <vector>
#include <fstream>
#include <ostream>
#include <sstream>

#define MAX_LEN (50)
#define PROC_UPTIME_FILE  ("/proc/uptime")
#define PRI_FIX "/log/"

static std::string module_name_ = "launchtest";
static std::string log_file_name_; 
static std::ifstream infile_;  // PRQA S 4634
static std::ofstream outfile_;  // PRQA S 4634

inline std::string generate_log_file_name(const std::string &module_name)
{
    return std::string(PRI_FIX) + module_name + std::string("_launch_time_log");
}

static int record_proc_uptime() {
    std::vector<std::string> str_vector_;
    std::string result;
    std::stringstream ss;
    char buf[MAX_LEN] = {0};

    //1. 读入/proc/uptime 取得系统当前运行时间
    infile_.open(std::string(PROC_UPTIME_FILE));
    if (!infile_.is_open()) {
        printf("Open %s fail.", PROC_UPTIME_FILE);
        return -1;
    }

    str_vector_.clear();
    infile_.getline(buf, MAX_LEN);
    ss << buf;

    //时间信息压入容器
    while (ss >> result)  // PRQA S ALL
        str_vector_.push_back(result);

    //2 打开结果输出文件
    log_file_name_ = generate_log_file_name(module_name_);
    outfile_.open(log_file_name_, std::ios::trunc); 

    if (!outfile_.is_open()) {
        printf("Open %s fail.", log_file_name_.c_str());
        return -1;
    } 

    //3 换算启动时间 并将结果写入文件
    const float ms = static_cast<float>(std::stof(str_vector_.front(), nullptr)) *1000U;    
    outfile_ << module_name_ << std::string(" start at time:") << ms << std::string(" ms\n");

    infile_.close();
    outfile_.close();
    return 0;
}


int main(int argc, const char *argv[])
{
    int ret = 0;

    std::cout << "__cplusplus = " << __cplusplus << std::endl;
    ret = record_proc_uptime();
    if (ret) {
        printf("record_proc_uptime error ret = %d\n", ret); 
        return ret;
    }

    return 0;
}  


