#include <cstdlib>
#include <iostream>

int main() {
  const char* env_p = nullptr;
  if (env_p = std::getenv("PATH")) {
    std::string path_str = "echo ";
    path_str += env_p;
    path_str += " >> ./testenviroment";

    system(path_str.c_str());
    std::cout << "Your PATH is: " << env_p << '\n';
  }
  return 0;
}
