#include <stdio.h>
#include <stdlib.h>

#include <iostream> // std::cout
#include <thread>   // std::thread
#include <vector>

void thread_task() {
    std::cout << "hello thread" << std::endl;
}

/*
 * ===  FUNCTION  =========================================================
 *         Name:  main
 *  Description:  program entry routine.
 * ========================================================================
 */
int main(int argc, const char *argv[])
{
    std::cout << "__cplusplus = " << __cplusplus << std::endl;
    std::thread t(thread_task);
    t.join();

    std::vector<int> arr;
    arr.push_back(0);
    arr.push_back(1);

    for (auto n: arr)
    {
        std::cout << n << std::endl;
    }

    return EXIT_SUCCESS;
}  /* ----------  end of function main  ---------- */
