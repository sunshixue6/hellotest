#include "virtualClass.h"
#include <iostream>

namespace litest {
    VirtualClass::VirtualClass()
    {
        std::cout << "I am VirtualClass construct" << std::endl;
    }

    void VirtualClass::workTest()
    {
        std::cout << "P2ServerMin() is: " << _param.P2ServerMin().count() << std::endl;
        std::cout << "P2ServerMax() is: " << _param.P2ServerMax().count() << std::endl;
    }
}

