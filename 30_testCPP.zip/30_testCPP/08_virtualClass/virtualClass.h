/**
 * @copyright Copyright 2022
 *
 * No duplications, whole or partial, manual or electronic, may be made
 * without express written permission. Any such copies, or revisions thereof,
 * must display this notice unaltered.
 *
 * @brief
 * @author 
 * @date 2022-01-23
 */

#ifndef INCLUDE_VIRTUAL_CLASS_H_
#define INCLUDE_VIRTUAL_CLASS_H_

#include "virtualparam.h"

namespace litest {

class VirtualClass {
    public:
        VirtualClass();

        void workTest();
    private:
        Parameter _param;
};


} //end namespace litest

#endif

