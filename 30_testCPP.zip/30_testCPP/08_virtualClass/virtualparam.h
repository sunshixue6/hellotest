/**
 * @copyright Copyright 2022
 *
 * No duplications, whole or partial, manual or electronic, may be made
 * without express written permission. Any such copies, or revisions thereof,
 * must display this notice unaltered.
 *
 * @brief
 * @author 
 * @date 2022-01-23
 */

#ifndef INCLUDE_VIRTUAL_PARAMETERS_H_
#define INCLUDE_VIRTUAL_PARAMETERS_H_

#include <chrono>

namespace litest {

using namespace std::chrono_literals;  // NOLINT for use "ms" declater

class Parameter 
{
public:
  virtual std::chrono::microseconds P2ServerMin() { return 0ms; }  
  virtual std::chrono::microseconds P2ServerMax() { return 20ms; }  
};


} //end namespace litest

#endif //INCLUDE_VIRTUAL_PARAMETERS_H_