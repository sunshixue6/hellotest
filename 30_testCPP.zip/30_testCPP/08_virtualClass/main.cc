#include "virtualClass.h"
#include <memory>
#include <iostream>

int main(int argc, char **argv) {

    std::shared_ptr<litest::VirtualClass> virtulClass = std::make_shared<litest::VirtualClass>();
    virtulClass->workTest();

    return 0;
}
