#include <stdio.h>
#include <stdlib.h>

#include <iostream> // std::cout
#include <thread>   // std::thread
#include <vector>
#include <algorithm>

void thread_task() {
    std::cout << "hello thread" << std::endl;
}


class Test
{
    public:
        Test(int value)
        {
            this->value = value;
            std::cout << "constrort Test" << std::endl;
        }

        int funcTest() {
            auto cafunc = [this]{ return (2 * this->value); };
            return cafunc();
        }

    private:
        int value;
};

/*
 * ===  FUNCTION  =========================================================
 *         Name:  main
 *  Description:  program entry routine.
 * ========================================================================
 * // 完整语法
[ capture-list ] ( params ) mutable(optional) constexpr(optional)(c++17) exception attribute -> ret { body }

// 可选的简化语法
[ capture-list ] ( params ) -> ret { body }
[ capture-list ] ( params ) { body }
[ capture-list ] { body }
capture-list：捕捉列表，这个不用多说，前面已经讲过，记住它不能省略；
params：参数列表，可以省略（但是后面必须紧跟函数体）；
mutable：可选，将lambda表达式标记为mutable后，函数体就可以修改传值方式捕获的变量；
constexpr：可选，C++17，可以指定lambda表达式是一个常量函数；
exception：可选，指定lambda表达式可以抛出的异常；
attribute：可选，指定lambda表达式的特性；
ret：可选，返回值类型；
body：函数执行体。

 *
 *
 */
int main(int argc, const char *argv[])
{
    std::cout << "__cplusplus = " << __cplusplus << std::endl;
    auto basicLambda = []{ std::cout << "hello lambda" << std::endl; };
    basicLambda();

    // 指明返回类型
    auto add = [](int a, int b) -> int { return a + b; };

    // 自动推断返回类型
    auto multiply = [](int a, int b) { return a * b; };
    int sum = add(2, 5);   // 输出：7
    int product = multiply(2, 5);  //输出：10

    auto retprint = [&sum, &product]{std::cout <<"sum:" << sum << "  product:" << product <<std::endl; };
    retprint();

    int x = 10;
    auto add_x = [x](int a) { return a + x; };  // 复制捕捉x
    auto multiply_x = [&x](int a) { return a * x; };  // 引用捕捉x
    std::cout << add_x(10) << " " << multiply_x(10) << std::endl;


    Test testA(10);
    std::cout << testA.funcTest() <<std::endl;

    int value = 3;
    std::vector<int> v {1, 3, 5, 2, 6, 10};

    int count = std::count_if(v.begin(), v.end(), [value](int x) { return x > value; });
    std::cout << " vector > 3 count is: " << count <<std::endl;


    int xx = 4;
    auto y = [&r = xx, xx = xx + 1] { r += 2; return xx * xx; }();
    // 此时 x 更新为6，y 为25

    return EXIT_SUCCESS;
}  /* ----------  end of function main  ---------- */
