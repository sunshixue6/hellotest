#include <chrono>
#include <cstdio>
#include <exception>
#include <fstream>
#include <functional>
#include <iostream>
#include <regex>
#include <string>
#include <stdio.h>

//namespace common {

struct SemVer {
  uint8_t major;
  uint8_t minor;
  uint8_t revise;
};

inline bool utils_parse_semversion(const std::string &content, SemVer &sem_ver) {  // NOLINT
  std::match_results<std::string::const_iterator> result;
  std::regex version_regex("(\\d{1,2})\\.(\\d{1,2})\\.(\\d{1,2})");

  if (std::regex_search(content, result, version_regex)) {
    printf("semver matched %s \n", result[0].str().c_str());

    sem_ver.major = std::stoi(result[1].str());
    sem_ver.minor = std::stoi(result[2].str());
    sem_ver.revise = std::stoi(result[3].str());

    return true;
  } else {
    printf("semver not matched\n");
  }

  return false;
}

//} //namespace common


//using namespace common;

int main()
{
    struct SemVer sem_ver;
    utils_parse_semversion("199.10.01", sem_ver);
    printf("The maior ver is %d\n", sem_ver.major);
    return 0;
}
